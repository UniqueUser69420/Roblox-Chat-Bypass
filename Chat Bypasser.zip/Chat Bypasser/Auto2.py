import keyboard

# The replacement dictionary 
replacement_dict = {'a': 'ɐ', 'b': 'q', 'c': 'ɔ', 'd': 'p', 'e': 'ǝ', 'f': 'ɟ', 'g': 'ƃ', 'h': 'ɥ', 'i': 'ᴉ', 'j': 'ɾ', 'k': 'ʞ', 'l': 'l', 'm': 'ɯ', 'n': 'u', 'o': 'o', 'p': 'd', 'q': 'b', 'r': 'ɹ', 's': 's', 't': 'ʇ', 'u': 'n', 'v': 'ʌ', 'w': 'ʍ', 'x': 'x', 'y': 'ʎ', 'z': 'z', '0': 'Ɩ', '1': 'ᄅ', '2': 'Ɛ', '3': 'ㄣ', '4': 'ϛ', '5': '9', '6': 'ㄥ', '7': '8', '8': '9', '9': '0'}

# Function to handle key presses
def on_press(event):
    char = event.name
    if len(char) == 1:  # Check if it's a single character
        char = char.lower()
        if char in replacement_dict:
            keyboard.press_and_release('backspace')
            replacement = replacement_dict[char]
            keyboard.write(replacement)

# Create a keyboard hook and attach the on_press function
keyboard.hook(on_press)

# Keep the script running
keyboard.wait('esc')  # Wait for the 'esc' key to be pressed to exit