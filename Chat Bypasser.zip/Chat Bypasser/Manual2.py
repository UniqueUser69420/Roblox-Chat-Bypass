import tkinter as tk

# Dictionary for text replacement
replacement_dict = {    
    'a': '🇦 ', 'b': '🇧 ', 'c': '🇨 ', 'd': '🇩 ', 'e': '🇪 ', 'f': '🇫 ', 'g': '🇬 ', 'h': '🇭 ', 'i': '🇮 ',
    'j': '🇯 ', 'k': '🇰 ', 'l': '🇱 ', 'm': '🇲 ', 'n': '🇳 ', 'o': '🇴 ', 'p': '🇵 ', 'q': '🇶 ', 'r': '🇷 ',
    's': '🇸 ', 't': '🇹 ', 'u': '🇺 ', 'v': '🇻 ', 'w': '🇼 ', 'x': '🇽 ', 'y': '🇾 ', 'z': '🇿 ',
    ' ': ' ',  # Include space for handling spaces
    '0': '⓪', '1': '⓵', '2': '⓶', '3': '⓷', '4': '⓸', '5': '⓹', '6': '⓺', '7': '⓻', '8': '⓼', '9': '⓽',
    '!': '❗', '@': 'Ⓐ', '#': '＃', '$': '＄', '%': '％', '^': '＾' 
}

def on_key_press(event):
    # Get the entire content of the input_text widget
    text = input_text.get("1.0", tk.END).lower()

    # Convert the text using the replacement_dict
    converted_text = "".join(replacement_dict.get(char, char) for char in text)

    # Delete existing content in the output_text widget
    output_text.config(state='normal')  # Temporarily enable editing to clear
    output_text.delete("1.0", tk.END)

    # Insert the converted text
    output_text.insert(tk.END, converted_text)

    # Make the output_text widget uneditable
    output_text.config(state='disabled')

def clear_output():
    # Clear the output text area
    output_text.config(state='normal')
    output_text.delete("1.0", tk.END)
    output_text.config(state='disabled')
    # Clear the input text area
    input_text.delete("1.0", tk.END)

def copy_to_clipboard():
    # Get the modified text from the output_text widget
    modified_text = output_text.get("1.0", tk.END)

    # Copy the text to the clipboard (implementation depends on your platform)
    window.clipboard_clear()
    window.clipboard_append(modified_text)

    # Update the copy status message
    copy_status.set("Copied!")

    # Schedule a reset of the message after a delay
    window.after(2000, lambda: copy_status.set("Ready"))

# Create the main window
window = tk.Tk()
window.title("Text Converter")

# Create a StringVar to hold the copy status message
copy_status = tk.StringVar(value="Ready")

# Create a label to display the copy status
copy_status_label = tk.Label(window, textvariable=copy_status)
copy_status_label.pack()

# Create input and output text areas
input_text = tk.Text(window, height=5, width=30)
input_text.pack()

output_text = tk.Text(window, height=5, width=30)
output_text.config(state='disabled') # Make output_text uneditable initially
output_text.pack()

# Create a clear button
clear_button = tk.Button(window, text="Clear", command=clear_output)
clear_button.pack()

# Create a copy button
copy_button = tk.Button(window, text="Copy", command=copy_to_clipboard)
copy_button.pack()

# Bind the key press event to the input text area
input_text.bind("<KeyPress>", on_key_press)

# Start the GUI event loop
window.mainloop()