import keyboard

# The replacement dictionary from the 'lib.txt' file
replacement_dict = {
    'a': '🅰', 'b': '🅱', 'c': '🅲', 'd': '🅳', 'e': '🅴', 'f': '🅵', 'g': '🅶',
    'h': '🅷', 'i': '🅸', 'j': '🅹', 'k': '🅺', 'l': '🅻', 'm': '🅼', 'n': '🅽',
    'o': '🅾', 'p': '🅿', 'q': '🆀', 'r': '🆁', 's': '🆂', 't': '🆃', 'u': '🆄',
    'v': '🆅', 'w': '🆆', 'x': '🆇', 'y': '🆈', 'z': '🆉',
    ' ': ' ',  # Include space for handling spaces
    '0': '⓪', '1': '⓵', '2': '⓶', '3': '⓷', '4': '⓸', '5': '⓹', '6': '⓺', '7': '⓻', '8': '⓼', '9': '⓽',
    '!': '❗', '@': 'Ⓐ', '#': '＃', '$': '＄', '%': '％', '^': '＾' 
}

# Function to handle key presses
def on_press(event):
    char = event.name
    if len(char) == 1:  # Check if it's a single character
        char = char.lower()
        if char in replacement_dict:
            keyboard.press_and_release('backspace')
            replacement = replacement_dict[char]
            keyboard.write(replacement)

# Create a keyboard hook and attach the on_press function
keyboard.hook(on_press)

# Keep the script running
keyboard.wait('esc')  # Wait for the 'esc' key to be pressed to exit