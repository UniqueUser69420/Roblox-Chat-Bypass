import tkinter as tk
import subprocess
import os

current_process = None

def open_script(script_name):
    """Opens the specified Python script and terminates any previously running script."""
    global current_process

    # Terminate the previously running script if any
    if current_process:
        current_process.terminate()

    filepath = os.path.join(os.getcwd(), script_name)  # Get the full path in the current directory

    try:
        current_process = subprocess.Popen(["python", filepath])
    except FileNotFoundError:
        tk.messagebox.showerror("Error", f"Script '{script_name}' not found in the current directory.")

# Create the main window
window = tk.Tk()
window.title("Python Script Switcher")

# Create buttons to open each script
button1 = tk.Button(window, text="Open Auto1.py", command=lambda: open_script("Auto1.py"))
button1.pack(pady=10)

button2 = tk.Button(window, text="Open Auto2.py", command=lambda: open_script("Auto2.py"))
button2.pack(pady=10)

# Start the GUI event loop
window.mainloop()